﻿================================================================================
                    REDMINE CONNECTOR PRO v1.0.1
             Cliente Profesional de Escritorio para Redmine
================================================================================

INDICE
------
1. Requisitos del Sistema
2. Instalacion Rapida
3. Como Ejecutar
4. Actualizacion desde Version Anterior
5. Caracteristicas Principales
6. Contenido del Paquete
7. Solucion de Problemas
8. Novedades de esta Version
9. Informacion Tecnica
10. Licencia y Soporte

================================================================================
1. REQUISITOS DEL SISTEMA
================================================================================

[OBLIGATORIO]
  - Java JRE 8 o superior
    Descargar desde cualquiera de estas fuentes fiables:
      * Eclipse Adoptium (Temurin): https://adoptium.net/
      * Azul Zulu:                  https://www.azul.com/downloads/
      * Amazon Corretto:            https://aws.amazon.com/corretto/
      * Red Hat OpenJDK:            https://developers.redhat.com/products/openjdk/download
      * Oracle Java:                https://www.oracle.com/java/technologies/downloads/
    Recomendado: Temurin JRE 17 (LTS)

[SISTEMAS COMPATIBLES]
  - Windows 7, 8, 10, 11 (64-bit)
  - Linux (cualquier distribucion moderna)
  - macOS 10.12 o superior

[MEMORIA]
  - Minimo: 256 MB RAM libres
  - Recomendado: 512 MB RAM libres

================================================================================
2. INSTALACION RAPIDA
================================================================================

Paso 1: Descomprime este archivo ZIP en cualquier carpeta
        Ejemplo: C:\Programas\RedmineConnector\

Paso 2: Asegurate de tener Java instalado
        Verifica ejecutando: java -version

Paso 3: Listo! No requiere instalacion adicional

NOTA: La aplicacion es 100% portable. Puedes moverla a cualquier ubicacion
      o ejecutarla desde un USB sin problemas.

================================================================================
3. COMO EJECUTAR
================================================================================

[WINDOWS]
  Metodo 1: Doble clic en RedmineConnector.bat
  Metodo 2: Desde CMD/PowerShell:
            java -jar RedmineConnector.jar

[LINUX / macOS]
  Desde terminal:
  java -jar RedmineConnector.jar

[PARAMETROS OPCIONALES]
  Mas memoria (recomendado para proyectos grandes):
  java -Xmx1024m -jar RedmineConnector.jar

  Modo debug (para diagnostico):
  java -Dlog.level=DEBUG -jar RedmineConnector.jar

================================================================================
4. ACTUALIZACION DESDE VERSION ANTERIOR
================================================================================

Si actualizas desde una version anterior y experimentas:
  - Tablas con fondo negro
  - Colores incorrectos
  - Problemas visuales

SOLUCION: Borra el archivo de configuracion viejo

[Windows]
  1. Cierra la aplicacion
  2. Presiona Windows+R
  3. Escribe: %APPDATA%\RedmineConnector
  4. Borra el archivo: config.properties
  5. Reinicia la aplicacion

[Linux]
  rm ~/.config/RedmineConnector/config.properties

[macOS]
  rm ~/Library/Application\ Support/RedmineConnector/config.properties

La aplicacion creara una nueva configuracion con los valores corregidos.

================================================================================
5. CARACTERISTICAS PRINCIPALES
================================================================================

GESTION DE TAREAS
  [ OK ] Creacion y edicion de issues
  [ OK ] Asignacion de tareas
  [ OK ] Seguimiento de estado
  [ OK ] Gestion de prioridades
  [ OK ] Adjuntos y comentarios
  [ OK ] Relaciones entre issues

PRODUCTIVIDAD
  [ OK ] Modo offline con cache inteligente
  [ OK ] Busqueda global avanzada
  [ OK ] Filtros personalizables
  [ OK ] Ordenacion multi-columna
  [ OK ] Vista rapida (Quick View)
  [ OK ] Drag & Drop de archivos

REPORTES Y METRICAS
  [ OK ] Dashboard de metricas en tiempo real
  [ OK ] Estadisticas por usuario/proyecto
  [ OK ] Graficos de progreso
  [ OK ] Analisis de carga de trabajo
  [ OK ] Exportacion a CSV
  [ OK ] Reportes personalizados

GESTION AVANZADA
  [ OK ] Wiki manager completo
  [ OK ] Version manager
  [ OK ] Kanban board interactivo
  [ OK ] Time tracking integrado
  [ OK ] Gestion de versiones
  [ OK ] Configuracion de targets

PERSONALIZACION
  [ OK ] Temas visuales (claro/oscuro)
  [ OK ] Idiomas: Espanol e Ingles
  [ OK ] Colores por estado
  [ OK ] Configuracion de columnas
  [ OK ] Atajos de teclado

CALIDAD
  [ OK ] 188 tests automatizados (100% pass)
  [ OK ] 72% cobertura de codigo
  [ OK ] Zero dependencias externas
  [ OK ] Arquitectura MVC robusta

================================================================================
6. CONTENIDO DEL PAQUETE
================================================================================

RedmineConnector.jar     Aplicacion principal (800 KB aprox.)
                         Incluye todos los idiomas y recursos

RedmineConnector.bat     Launcher para Windows
                         Verifica Java automaticamente

resources/               Iconos y recursos visuales
                         Usado por la aplicacion

docs/                    Manual de usuario en HTML
                         Abre docs/index.html en tu navegador

README.txt               Este archivo
                         Instrucciones completas

================================================================================
7. SOLUCION DE PROBLEMAS
================================================================================

PROBLEMA: "Java no encontrado" o "java: command not found"
SOLUCION: 
  1. Instala Java JRE 8+ desde una fuente fiable:
     - https://adoptium.net/ (Recomendado)
     - https://www.azul.com/downloads/
     - https://aws.amazon.com/corretto/
     - https://www.oracle.com/java/technologies/downloads/
  2. Reinicia tu terminal/CMD
  3. Verifica con: java -version

PROBLEMA: Tablas con fondo negro
SOLUCION:
  Ver seccion "4. ACTUALIZACION DESDE VERSION ANTERIOR"
  Borra config.properties y reinicia

PROBLEMA: No se ven los textos en espanol
SOLUCION:
  Los archivos de idioma estan incluidos en el JAR desde v1.0.1
  Si persiste, borra config.properties

PROBLEMA: La aplicacion no arranca
SOLUCION:
  1. Abre CMD/Terminal
  2. Navega a la carpeta: cd [carpeta-de-la-app]
  3. Ejecuta: java -jar RedmineConnector.jar
  4. Copia cualquier error que aparezca

PROBLEMA: OutOfMemoryError o "Java heap space"
SOLUCION:
  Usa el launcher .bat que asigna 512MB automaticamente
  O ejecuta: java -Xmx1024m -jar RedmineConnector.jar

PROBLEMA: Conexion SSL fallida
SOLUCION:
  Si tu servidor Redmine usa HTTPS con certificado propio:
  1. Exporta el certificado (.cer)
  2. Importalo al keystore de Java:
     keytool -import -alias redmine -file cert.cer -keystore cacerts

PROBLEMA: Datos desactualizados o errores de renderizado
SOLUCION:
  A veces la cache local puede corromperse.
  1. Cierra la aplicacion
  2. Borra el archivo de cache:
     [Windows] %USERPROFILE%\.redmine_connector_cache.dat
     [Linux/Mac] ~/.redmine_connector_cache.dat
  3. Borra el archivo de configuracion (reset completo):
     [Windows] %APPDATA%\RedmineConnector\config.properties
     [Linux/Mac] ~/.config/RedmineConnector/config.properties
  4. Reinicia la aplicacion

================================================================================
8. NOVEDADES DE ESTA VERSION (v1.0.1)
================================================================================

RESUMEN DE FUNCIONALIDADES
--------------------------
*   **Gestion de Tareas**: Crear, editar, clonar y organizar tareas.
*   **Prioridades Configurables**: Personaliza colores y estilos (negrita) para Urgente, Inmediata, etc.
*   **Multi-Instancia**: Sincronizacion y clonado entre servidores Redmine.
*   **Modo Offline**: Cache local inteligente para trabajar sin conexion.
*   **Dashboard**: Metricas de productividad y graficos.

*   **Wiki/Versiones**: Gestores dedicados para Wiki y Versiones del proyecto.
*   **Cierre Sincronizado**: Cierra tareas gemelas en multiples entornos a la vez.

CAMBIOS RECIENTES
-----------------

  [FIX] Fondos negros en tablas - RESUELTO
  [FIX] CustomTheme con defaults seguros
  [FIX] UIManager configuracion completa

MEJORAS DE INTERFAZ
  [NEW] 11 constantes de color en AppConstants
  [UPD] Tema claro con colores mejorados
  [UPD] Renderizado consistente multiplataforma

MEJORAS TECNICAS
  [NEW] 188 tests unitarios (100% pass rate)
  [NEW] Tests para AppConstants
  [NEW] Validacion de constantes
  [UPD] Javadoc completo en AppConstants
  [UPD] 77+ constantes centralizadas

EMPAQUETADO
  [NEW] Script build-complete.ps1 automatizado
  [UPD] Archivos de idioma incluidos en JAR
  [UPD] README mejorado (este archivo)
  [UPD] Documentacion de distribucion

RENDIMIENTO
  [OPT] Cache de imagenes mejorado
  [OPT] Thread pool optimizado
  [OPT] Reduccion de magic numbers
  
PARA MAS DETALLES: Ver CHANGELOG.md

================================================================================
9. INFORMACION TECNICA
================================================================================

Lenguaje:        Java 8+
Framework UI:    Swing (nativo Java)
Arquitectura:    MVC con servicios asincronos
Base de datos:   Ninguna (usa API REST de Redmine)
Dependencias:    CERO dependencias externas
                 100% Java Standard Library

Testing:         188 tests unitarios
Cobertura:       72% total, 45% UI
Pass Rate:       100% (todos los tests pasan)

Tamano JAR:      ~800 KB (comprimido)
Tamano ZIP:      ~2-3 MB (con docs y recursos)
Memoria minima:  256 MB
Memoria recom:   512 MB

Plataformas:     Windows, Linux, macOS
Compatibilidad:  Redmine 3.x, 4.x, 5.x
API Version:     Redmine REST API v1

Desarrollado:    100% compatible Java 8
Probado en:      Java 8, 11, 17, 21

================================================================================
10. LICENCIA Y SOPORTE
================================================================================

Desarrollado por:  Redmine Connector Team
Version:           1.0.1
Fecha de release:  2026-02-26

Para reportar bugs, solicitar features o soporte tecnico:
Contacta con el equipo de desarrollo

Los bugs conocidos y roadmap estan documentados en el proyecto.

PRIVACIDAD:
Esta aplicacion NO envia telemetria. NO recopila datos de usuario.
Toda la informacion se almacena localmente en tu equipo.

SEGURIDAD:
Las credenciales se almacenan cifradas en config.properties
El cifrado usa el algoritmo AES provisto por Java

================================================================================

Gracias por usar Redmine Connector Pro!

Para comenzar: Ejecuta RedmineConnector.bat
Para ayuda:    Abre docs/index.html
Para soporte:  Contacta al equipo de desarrollo

================================================================================
