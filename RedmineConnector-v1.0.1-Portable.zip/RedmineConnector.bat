@echo off
title Redmine Connector Pro v1.0.1
color 0A
cls

echo ========================================
echo   Redmine Connector Pro v1.0.1
echo ========================================
echo.

REM Verificar Java
where java >nul 2>nul
if errorlevel 1 (
    color 0C
    echo [ERROR] Java no encontrado
    echo.
    echo Descarga Java JRE 8+ desde cualquiera de estas fuentes:
    echo   * Eclipse Adoptium: https://adoptium.net/
    echo   * Azul Zulu:        https://www.azul.com/downloads/
    echo   * Amazon Corretto:  https://aws.amazon.com/corretto/
    echo   * Oracle Java:      https://www.oracle.com/java/technologies/downloads/
    echo.
    pause
    exit /b 1
)

echo Verificando Java...
java -version
echo.

REM Verificar JAR
if not exist "RedmineConnector.jar" (
    color 0C
    echo [ERROR] RedmineConnector.jar no encontrado
    pause
    exit /b 1
)

echo [OK] Iniciando aplicacion...
echo.
echo NOTA: Si es la primera vez, borra el archivo de configuracion viejo:
echo   %%APPDATA%%\RedmineConnector\config.properties
echo.

REM Iniciar aplicacion (con mas memoria)
start javaw -Xms256m -Xmx512m -Dfile.encoding=UTF-8 -jar RedmineConnector.jar

timeout /t 2 /nobreak >nul
exit
